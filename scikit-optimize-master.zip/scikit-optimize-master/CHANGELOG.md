# Release history
See https://scikit-optimize.github.io/dev/whats_new.html

# Contributors

See `AUTHORS.md`.
