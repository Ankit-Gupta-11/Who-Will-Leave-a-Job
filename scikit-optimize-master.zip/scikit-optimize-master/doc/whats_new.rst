.. currentmodule:: skopt

Release History
===============

Release notes for all scikit-optimize releases are linked in this this page.

.. toctree::
    :maxdepth: 1

    Version 0.9 <whats_new/v0.9.rst>
    Version 0.8 <whats_new/v0.8.rst>
    Version 0.7 <whats_new/v0.7.rst>
    Version 0.6 <whats_new/v0.6.rst>
    Version 0.5 <whats_new/v0.5.rst>
    Version 0.4 <whats_new/v0.4.rst>
    Version 0.3 <whats_new/v0.3.rst>
    Version 0.2 <whats_new/v0.2.rst>
    Version 0.1 <whats_new/v0.1.rst>
