.. currentmodule:: skopt.benchmarks

.. _benchmarks:

Benchmarks
==========
A collection of benchmark problems.