.. _sampler_examples:

Initial sampling functions
--------------------------

Examples concerning the :mod:`skopt.sampler` module.
